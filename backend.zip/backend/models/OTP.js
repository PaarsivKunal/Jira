import mongoose from 'mongoose';

const otpSchema = mongoose.Schema(
  {
    email: {
      type: String,
      required: true,
      lowercase: true,
      trim: true,
      index: true, // Index for faster lookups
    },
    otp: {
      type: String,
      required: true,
    },
    expiresAt: {
      type: Date,
      required: true,
      default: () => new Date(Date.now() + 10 * 60 * 1000), // 10 minutes from now
      index: { expireAfterSeconds: 0 }, // TTL Index - MongoDB will auto-delete after expiresAt
    },
    verified: {
      type: Boolean,
      default: false,
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

// Compound index for faster queries
otpSchema.index({ email: 1, verified: 1 });
otpSchema.index({ userId: 1, verified: 1 });

// The TTL index on expiresAt will automatically delete documents when expiresAt time passes
// MongoDB runs a background task every 60 seconds to remove expired documents

const OTP = mongoose.model('OTP', otpSchema);

export default OTP;

