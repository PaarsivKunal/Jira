import User from '../models/User.js';
import OTP from '../models/OTP.js';
import { generateToken } from '../utils/generateToken.js';
import { generateOTP } from '../utils/generateOTP.js';
import { sendOTPEmail } from '../utils/emailService.js';

// @desc    Register new user (sends OTP)
// @route   POST /api/auth/register
// @access  Public
export const register = async (req, res) => {
  try {
    const { name, email, password, role } = req.body;

    const userExists = await User.findOne({ email });

    if (userExists) {
      return res.status(400).json({ message: 'User already exists' });
    }

    // Check if there's an unverified OTP for this email that hasn't expired
    const existingOTP = await OTP.findOne({
      email: email.toLowerCase(),
      verified: false
    });

    if (existingOTP && existingOTP.expiresAt > new Date()) {
      return res.status(400).json({
        message: 'Verification code already sent. Please check your email or wait before requesting a new one.'
      });
    }

    // Create user with verified email (OTP Disabled)
    const user = await User.create({
      name,
      email: email.toLowerCase(),
      password,
      role: role || 'developer',
      isEmailVerified: true, // Auto-verify
    });

    // Generate token immediately
    const token = generateToken(user._id);

    res.status(201).json({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      avatar: user.avatar,
      token,
      message: 'Registration successful',
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Verify OTP and activate account
// @route   POST /api/auth/verify-otp
// @access  Public
export const verifyOTP = async (req, res) => {
  try {
    const { email, otp } = req.body;

    if (!email || !otp) {
      return res.status(400).json({ message: 'Email and OTP are required' });
    }

    // Find the OTP
    const otpRecord = await OTP.findOne({
      email: email.toLowerCase(),
      otp,
      verified: false
    });

    if (!otpRecord) {
      return res.status(400).json({
        message: 'Invalid or expired verification code. Please request a new one.'
      });
    }

    // Double-check expiration (even though TTL should handle it)
    if (otpRecord.expiresAt < new Date()) {
      // Delete expired OTP if still exists
      await OTP.deleteOne({ _id: otpRecord._id });
      return res.status(400).json({
        message: 'Verification code has expired. Please request a new one.'
      });
    }

    // Find user
    const user = await User.findById(otpRecord.userId);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    if (user.isEmailVerified) {
      return res.status(400).json({ message: 'Email already verified' });
    }

    // Mark OTP as verified
    otpRecord.verified = true;
    await otpRecord.save();

    // Update user email verification status
    user.isEmailVerified = true;
    user.emailVerifiedAt = new Date();
    await user.save();

    // Delete all OTPs for this email (cleanup)
    await OTP.deleteMany({ email: email.toLowerCase() });

    // Generate token
    const token = generateToken(user._id);

    res.status(200).json({
      message: 'Email verified successfully',
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      avatar: user.avatar,
      isEmailVerified: user.isEmailVerified,
      token,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Resend OTP
// @route   POST /api/auth/resend-otp
// @access  Public
export const resendOTP = async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ message: 'Email is required' });
    }

    // Check if user exists
    const user = await User.findOne({ email: email.toLowerCase() });

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    if (user.isEmailVerified) {
      return res.status(400).json({ message: 'Email already verified' });
    }

    // Delete old unverified OTPs for this email
    await OTP.deleteMany({ email: email.toLowerCase(), verified: false });

    // Generate new OTP
    const otpCode = generateOTP(6);
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes from now

    // Save new OTP
    await OTP.create({
      email: email.toLowerCase(),
      otp: otpCode,
      expiresAt: expiresAt,
      userId: user._id,
      verified: false,
    });

    // Send OTP email
    try {
      await sendOTPEmail(email.toLowerCase(), otpCode);
      res.status(200).json({
        message: 'Verification code resent successfully. Please check your email.',
        expiresAt: expiresAt.toISOString(),
      });
    } catch (emailError) {
      await OTP.deleteOne({ email: email.toLowerCase() });
      return res.status(500).json({
        message: 'Failed to send verification email. Please try again.'
      });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Auth user & get token
// @route   POST /api/auth/login
// @access  Public
export const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ email });

    if (user && (await user.matchPassword(password))) {
      // Check if email is verified
      // OTP Disabled: Skip verification check
      /* if (!user.isEmailVerified) {
        return res.status(403).json({ 
          message: 'Please verify your email before logging in',
          email: user.email,
        });
      } */

      res.json({
        _id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        avatar: user.avatar,
        token: generateToken(user._id),
      });
    } else {
      res.status(401).json({ message: 'Invalid email or password' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get current user
// @route   GET /api/auth/me
// @access  Private
export const getMe = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select('-password');
    res.json(user);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

