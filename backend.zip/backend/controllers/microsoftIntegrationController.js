import axios from 'axios';
import MicrosoftIntegration from '../models/MicrosoftIntegration.js';
import { getUserTeams, getTeamChannels, getValidAccessToken } from '../services/microsoftGraphService.js';

/**
 * Get OAuth URL for Microsoft authentication
 */
export const getMicrosoftAuthUrl = async (req, res) => {
  try {
    const { integrationType } = req.query; // 'outlook', 'teams', or 'both'
    
    const scopes = {
      outlook: 'https://graph.microsoft.com/Mail.Send https://graph.microsoft.com/Calendars.ReadWrite',
      teams: 'https://graph.microsoft.com/ChannelMessage.Send https://graph.microsoft.com/Team.ReadBasic.All',
      both: 'https://graph.microsoft.com/Mail.Send https://graph.microsoft.com/Calendars.ReadWrite https://graph.microsoft.com/ChannelMessage.Send https://graph.microsoft.com/Team.ReadBasic.All',
    };

    const scope = scopes[integrationType] || scopes.both;
    const redirectUri = `${process.env.BACKEND_URL || 'http://localhost:5000'}/api/microsoft/callback`;
    const clientId = process.env.MICROSOFT_CLIENT_ID;
    const tenantId = process.env.MICROSOFT_TENANT_ID;

    if (!clientId || !tenantId) {
      return res.status(500).json({ message: 'Microsoft integration not configured' });
    }

    const authUrl = `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/authorize?` +
      `client_id=${clientId}&` +
      `response_type=code&` +
      `redirect_uri=${encodeURIComponent(redirectUri)}&` +
      `response_mode=query&` +
      `scope=${encodeURIComponent(scope)}&` +
      `state=${req.user._id}_${integrationType}`;

    res.json({ authUrl });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

/**
 * Handle OAuth callback
 */
export const handleMicrosoftCallback = async (req, res) => {
  try {
    const { code, state, error } = req.query;

    if (error) {
      return res.redirect(`${process.env.FRONTEND_URL || 'http://localhost:5173'}/settings?error=auth_failed`);
    }

    if (!code || !state) {
      return res.redirect(`${process.env.FRONTEND_URL || 'http://localhost:5173'}/settings?error=missing_params`);
    }

    const [userId, integrationType] = state.split('_');

    if (!userId || !integrationType) {
      return res.redirect(`${process.env.FRONTEND_URL || 'http://localhost:5173'}/settings?error=invalid_state`);
    }

    // Exchange code for tokens
    const tokenResponse = await axios.post(
      `https://login.microsoftonline.com/${process.env.MICROSOFT_TENANT_ID}/oauth2/v2.0/token`,
      new URLSearchParams({
        client_id: process.env.MICROSOFT_CLIENT_ID,
        client_secret: process.env.MICROSOFT_CLIENT_SECRET,
        code,
        redirect_uri: `${process.env.BACKEND_URL || 'http://localhost:5000'}/api/microsoft/callback`,
        grant_type: 'authorization_code',
      }),
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
      }
    );

    const { access_token, refresh_token, expires_in } = tokenResponse.data;
    const expiresAt = new Date(Date.now() + expires_in * 1000);

    // Get user info
    const userResponse = await axios.get('https://graph.microsoft.com/v1.0/me', {
      headers: { Authorization: `Bearer ${access_token}` },
    });

    const email = userResponse.data.mail || userResponse.data.userPrincipalName;

    // Save integration
    let integration = await MicrosoftIntegration.findOne({ userId });

    if (!integration) {
      integration = await MicrosoftIntegration.create({
        userId,
        integrationType,
      });
    }

    if (integrationType === 'outlook' || integrationType === 'both') {
      integration.outlook = {
        accessToken: access_token,
        refreshToken: refresh_token,
        expiresAt,
        email,
        isConnected: true,
      };
    }

    if (integrationType === 'teams' || integrationType === 'both') {
      integration.teams = {
        accessToken: access_token,
        refreshToken: refresh_token,
        expiresAt,
        tenantId: process.env.MICROSOFT_TENANT_ID,
        isConnected: true,
      };
    }

    if (integrationType === 'both') {
      integration.integrationType = 'both';
    } else {
      integration.integrationType = integrationType;
    }

    await integration.save();

    res.redirect(`${process.env.FRONTEND_URL || 'http://localhost:5173'}/settings?success=connected`);
  } catch (error) {
    console.error('OAuth callback error:', error.response?.data || error.message);
    res.redirect(`${process.env.FRONTEND_URL || 'http://localhost:5173'}/settings?error=connection_failed`);
  }
};

/**
 * Get user's integration status
 */
export const getIntegrationStatus = async (req, res) => {
  try {
    const integration = await MicrosoftIntegration.findOne({ userId: req.user._id });

    if (!integration) {
      return res.json({
        outlook: { isConnected: false },
        teams: { isConnected: false },
        settings: {
          sendEmailNotifications: true,
          sendTeamsNotifications: true,
          notifyOnIssueCreate: true,
          notifyOnIssueUpdate: true,
          notifyOnComment: true,
          notifyOnStatusChange: true,
          notifyOnAssignment: true,
        },
      });
    }

    res.json({
      outlook: {
        isConnected: integration.outlook?.isConnected || false,
        email: integration.outlook?.email || null,
      },
      teams: {
        isConnected: integration.teams?.isConnected || false,
        teamId: integration.teams?.teamId || null,
        channelId: integration.teams?.channelId || null,
      },
      settings: integration.settings,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

/**
 * Get user's Teams
 */
export const getUserTeamsList = async (req, res) => {
  try {
    const integration = await MicrosoftIntegration.findOne({
      userId: req.user._id,
      'teams.isConnected': true,
    });

    if (!integration) {
      return res.status(400).json({ message: 'Teams not connected' });
    }

    const accessToken = await getValidAccessToken(
      integration,
      process.env.MICROSOFT_CLIENT_ID,
      process.env.MICROSOFT_CLIENT_SECRET,
      process.env.MICROSOFT_TENANT_ID
    );

    const teams = await getUserTeams(accessToken);
    res.json({ teams });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

/**
 * Get channels for a team
 */
export const getChannels = async (req, res) => {
  try {
    const { teamId } = req.params;
    const integration = await MicrosoftIntegration.findOne({
      userId: req.user._id,
      'teams.isConnected': true,
    });

    if (!integration) {
      return res.status(400).json({ message: 'Teams not connected' });
    }

    const accessToken = await getValidAccessToken(
      integration,
      process.env.MICROSOFT_CLIENT_ID,
      process.env.MICROSOFT_CLIENT_SECRET,
      process.env.MICROSOFT_TENANT_ID
    );

    const channels = await getTeamChannels(accessToken, teamId);
    res.json({ channels });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

/**
 * Configure Teams channel
 */
export const configureTeamsChannel = async (req, res) => {
  try {
    const { teamId, channelId } = req.body;
    const integration = await MicrosoftIntegration.findOne({ userId: req.user._id });

    if (!integration || !integration.teams?.isConnected) {
      return res.status(400).json({ message: 'Teams not connected' });
    }

    integration.teams.teamId = teamId;
    integration.teams.channelId = channelId;
    await integration.save();

    res.json({ message: 'Teams channel configured successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

/**
 * Update integration settings
 */
export const updateSettings = async (req, res) => {
  try {
    const integration = await MicrosoftIntegration.findOne({ userId: req.user._id });

    if (!integration) {
      return res.status(404).json({ message: 'Integration not found' });
    }

    integration.settings = { ...integration.settings, ...req.body };
    await integration.save();

    res.json({ message: 'Settings updated successfully', settings: integration.settings });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

/**
 * Disconnect integration
 */
export const disconnectIntegration = async (req, res) => {
  try {
    const { type } = req.body; // 'outlook', 'teams', or 'both'
    const integration = await MicrosoftIntegration.findOne({ userId: req.user._id });

    if (!integration) {
      return res.status(404).json({ message: 'Integration not found' });
    }

    if (type === 'outlook' || type === 'both') {
      integration.outlook = {
        isConnected: false,
        accessToken: null,
        refreshToken: null,
        expiresAt: null,
        email: null,
      };
    }

    if (type === 'teams' || type === 'both') {
      integration.teams = {
        isConnected: false,
        accessToken: null,
        refreshToken: null,
        expiresAt: null,
        teamId: null,
        channelId: null,
        tenantId: null,
      };
    }

    if (type === 'both') {
      integration.integrationType = 'both';
    }

    await integration.save();
    res.json({ message: 'Integration disconnected successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

