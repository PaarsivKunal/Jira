import Issue from '../models/Issue.js';
import Project from '../models/Project.js';
import Activity from '../models/Activity.js';
import { generateIssueKey } from '../utils/generateIssueKey.js';
import { getPaginationParams, createPaginationResponse } from '../utils/pagination.js';
import { CONSTANTS } from '../config/constants.js';
import { sendTeamsNotification } from '../services/teamsService.js';
import { sendIssueNotification, sendAssignmentNotification, sendIssueCreatedNotification } from '../utils/emailService.js';

const { ROLES, ISSUE } = CONSTANTS;

/**
 * Check if user has permission to modify an issue
 * Users can modify if they are:
 * - Admin
 * - Project lead or member
 * - Issue assignee
 * - Issue reporter
 */
const canModifyIssue = async (issue, userId, userRole) => {
  // Admin can modify any issue
  if (userRole === ROLES.ADMIN) {
    return true;
  }

  // Get project to check membership
  const project = await Project.findById(issue.projectId);
  if (!project) {
    return false;
  }

  // Check if user is project lead or member
  const isLead = project.lead.toString() === userId.toString();
  const isMember = project.members.some(
    (memberId) => memberId.toString() === userId.toString()
  );

  // Check if user is assignee or reporter
  const isAssignee = issue.assignee?.toString() === userId.toString();
  const isReporter = issue.reporter.toString() === userId.toString();

  return isLead || isMember || isAssignee || isReporter;
};

// @desc    Get all issues
// @route   GET /api/issues
// @access  Private
export const getIssues = async (req, res) => {
  try {
    const { projectId, status, assignee } = req.query;
    const { page, limit, skip } = getPaginationParams(req);
    const query = {};

    if (projectId) query.projectId = projectId;
    if (status) query.status = status;
    if (assignee) query.assignee = assignee;
    // Allow filtering by sprintId (or 'null' for backlog)
    if (req.query.sprintId) {
      query.sprintId = req.query.sprintId === 'null' ? null : req.query.sprintId;
    }

    // Filter by project access if not admin
    if (req.user.role !== ROLES.ADMIN && projectId) {
      const project = await Project.findById(projectId);
      if (project) {
        const isLead = project.lead.toString() === req.user._id.toString();
        const isMember = project.members.some(
          (memberId) => memberId.toString() === req.user._id.toString()
        );
        if (!isLead && !isMember) {
          return res.status(403).json({ message: 'Access denied to this project' });
        }
      }
    } else if (req.user.role !== ROLES.ADMIN) {
      // If no project specified and not admin, only show issues from allowed projects
      const allowedProjects = await Project.find({
        $or: [
          { lead: req.user._id },
          { members: req.user._id }
        ]
      }).select('_id');

      const allowedProjectIds = allowedProjects.map(p => p._id);
      query.projectId = { $in: allowedProjectIds };
    }


    const total = await Issue.countDocuments(query);
    const issues = await Issue.find(query)
      .populate('projectId', 'name key')
      .populate('assignee', 'name email avatar')
      .populate('reporter', 'name email avatar')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .lean();

    res.json(createPaginationResponse(issues, page, limit, total));
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get single issue
// @route   GET /api/issues/:id
// @access  Private
export const getIssue = async (req, res) => {
  try {
    const issue = await Issue.findById(req.params.id)
      .populate('projectId', 'name key')
      .populate('assignee', 'name email avatar')
      .populate('reporter', 'name email avatar')
      .populate({
        path: 'linkedIssues.issueId',
        populate: [
          { path: 'assignee', select: 'name email avatar' },
          { path: 'reporter', select: 'name email avatar' },
          { path: 'projectId', select: 'name key' },
        ],
      })
      .lean();

    if (!issue) {
      return res.status(404).json({ message: 'Issue not found' });
    }

    // Get child issues
    const childIssues = await Issue.find({ parentIssue: req.params.id })
      .populate('assignee', 'name email avatar')
      .populate('reporter', 'name email avatar')
      .populate('projectId', 'name key')
      .populate('projectId', 'name key')
      .sort({ createdAt: 1 })
      .lean();

    const issueObj = issue; // issue is already a POJO due to .lean()
    issueObj.childIssues = childIssues;

    res.json(issueObj);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Create issue
// @route   POST /api/issues
// @access  Private
export const createIssue = async (req, res) => {
  try {
    const { projectId, title, description, type, priority, assignee, labels, dueDate } = req.body;

    const projectData = await Project.findById(projectId);

    if (!projectData) {
      return res.status(404).json({ message: 'Project not found' });
    }

    const key = await generateIssueKey(projectData.key);

    const issue = await Issue.create({
      projectId,
      key,
      title,
      description,
      type: type || ISSUE.TYPE.TASK,
      priority: priority || ISSUE.PRIORITY.MEDIUM,
      assignee,
      reporter: req.user._id,
      labels: labels || [],
      dueDate,
    });

    // Create activity
    await Activity.create({
      issueId: issue._id,
      userId: req.user._id,
      action: 'created',
    });

    const populatedIssue = await Issue.findById(issue._id)
      .populate('projectId', 'name key')
      .populate('assignee', 'name email avatar')
      .populate('reporter', 'name email avatar');

    // Send notifications
    await Promise.all([
      sendTeamsNotification(populatedIssue, 'created'),
      sendIssueNotification(populatedIssue, 'created')
    ]);

    // Send email to assignee if issue was assigned during creation
    if (populatedIssue.assignee?.email) {
      sendIssueCreatedNotification(populatedIssue, populatedIssue.assignee).catch((error) => {
        console.error('Failed to send issue creation notification:', error);
      });
    }

    res.status(201).json(populatedIssue);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update issue
// @route   PUT /api/issues/:id
// @access  Private
export const updateIssue = async (req, res) => {
  try {
    const issue = await Issue.findById(req.params.id);

    if (!issue) {
      return res.status(404).json({ message: 'Issue not found' });
    }

    // Check authorization
    const hasPermission = await canModifyIssue(issue, req.user._id, req.user.role);
    if (!hasPermission) {
      return res.status(403).json({
        message: 'You do not have permission to modify this issue'
      });
    }

    const oldStatus = issue.status;
    const oldAssignee = issue.assignee?.toString();
    const oldPriority = issue.priority;
    const oldDescription = issue.description;

    const updatedIssue = await Issue.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    )
      .populate('projectId', 'name key')
      .populate('assignee', 'name email avatar')
      .populate('reporter', 'name email avatar');

    // Create activity for status change
    if (req.body.status && req.body.status !== oldStatus) {
      await Activity.create({
        issueId: issue._id,
        userId: req.user._id,
        action: 'status_changed',
        field: 'status',
        oldValue: oldStatus,
        newValue: req.body.status,
      });
    }

    // Create activity and send email for assignment change
    if (req.body.assignee && req.body.assignee.toString() !== oldAssignee) {
      await Activity.create({
        issueId: issue._id,
        userId: req.user._id,
        action: 'assigned',
        field: 'assignee',
        newValue: req.body.assignee,
      });

      // Send assignment notification email to new assignee
      if (updatedIssue.assignee?.email) {
        sendAssignmentNotification(updatedIssue, updatedIssue.assignee, req.user).catch((error) => {
          console.error('Failed to send assignment notification:', error);
        });
      }
    }

    // Create activity for priority change
    if (req.body.priority && req.body.priority !== oldPriority) {
      await Activity.create({
        issueId: issue._id,
        userId: req.user._id,
        action: 'updated',
        field: 'priority',
        oldValue: oldPriority,
        newValue: req.body.priority,
      });
    }

    // Create activity for description change
    if (req.body.description !== undefined && req.body.description !== oldDescription) {
      await Activity.create({
        issueId: issue._id,
        userId: req.user._id,
        action: 'updated',
        field: 'description',
      });
    }

    // Send notifications
    await Promise.all([
      sendTeamsNotification(updatedIssue, 'updated'),
      sendIssueNotification(updatedIssue, 'updated')
    ]);

    res.json(updatedIssue);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Delete issue
// @route   DELETE /api/issues/:id
// @access  Private
export const deleteIssue = async (req, res) => {
  try {
    const issue = await Issue.findById(req.params.id);

    if (!issue) {
      return res.status(404).json({ message: 'Issue not found' });
    }

    // Check authorization - only admin, project lead, or reporter can delete
    const project = await Project.findById(issue.projectId);
    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }

    const isAdmin = req.user.role === ROLES.ADMIN;
    const isLead = project.lead.toString() === req.user._id.toString();
    const isReporter = issue.reporter.toString() === req.user._id.toString();

    if (!isAdmin && !isLead && !isReporter) {
      return res.status(403).json({
        message: 'You do not have permission to delete this issue'
      });
    }

    await Issue.findByIdAndDelete(req.params.id);
    res.json({ message: 'Issue removed' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update issue status
// @route   PATCH /api/issues/:id/status
// @access  Private
export const updateIssueStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const issue = await Issue.findById(req.params.id);

    if (!issue) {
      return res.status(404).json({ message: 'Issue not found' });
    }

    // Check authorization
    const hasPermission = await canModifyIssue(issue, req.user._id, req.user.role);
    if (!hasPermission) {
      return res.status(403).json({
        message: 'You do not have permission to update this issue'
      });
    }

    const oldStatus = issue.status;
    issue.status = status;
    await issue.save();

    // Create activity
    await Activity.create({
      issueId: issue._id,
      userId: req.user._id,
      action: 'status_changed',
      field: 'status',
      oldValue: oldStatus,
      newValue: status,
    });

    const populatedIssue = await Issue.findById(issue._id)
      .populate('projectId', 'name key')
      .populate('assignee', 'name email avatar')
      .populate('reporter', 'name email avatar');

    // Send notifications
    await Promise.all([
      sendTeamsNotification(populatedIssue, 'updated'), // Status change is an update
      sendIssueNotification(populatedIssue, 'status updated')
    ]);

    res.json(populatedIssue);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
