export default {
    testEnvironment: 'node',
    verbose: true,
    transform: {},
    setupFilesAfterEnv: ['./tests/setup.js'],
};
